export type Id = string;
export type IResourceId = { _id: Id };
