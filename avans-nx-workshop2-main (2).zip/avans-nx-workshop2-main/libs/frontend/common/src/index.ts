export * from './lib/frontend-common.module';
