import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'avans-nx-workshop-columns',
    templateUrl: './columns.component.html',
    styles: []
})
export class ColumnsComponent implements OnInit {
    ngOnInit(): void {
        throw new Error('Method not implemented.');
    }
}
