/**
 * Base class for all entities that are part of communication to/from services.
 */
// import { Id } from '@avans-nx-workshop/shared/api';

export interface IEntity {
    readonly _id: string; //Id;
}
