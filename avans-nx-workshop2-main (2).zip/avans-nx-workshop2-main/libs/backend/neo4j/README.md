# neo4j

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test neo4j` to execute the unit tests via [Jest](https://jestjs.io).
