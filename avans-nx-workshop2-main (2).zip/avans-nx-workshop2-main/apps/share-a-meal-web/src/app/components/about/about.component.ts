import { Component } from '@angular/core';

@Component({
    selector: 'avans-nx-workshop-about',
    templateUrl: './about.component.html',
    styles: [],
})
export class AboutComponent {}
