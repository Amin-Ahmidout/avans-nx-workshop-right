import { Component } from '@angular/core';

@Component({
    selector: 'avans-nx-workshop-root',
    templateUrl: './app.component.html',
})
export class AppComponent {
    title = 'my-app';
}
